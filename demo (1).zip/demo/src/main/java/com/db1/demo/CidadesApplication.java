package com.db1.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CidadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CidadesApplication.class, args);
	}

}
